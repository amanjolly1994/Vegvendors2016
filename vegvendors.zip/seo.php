<?php
?>


<meta property="og:title" content="VEGVENDORS" />
		<meta property="og:type" content="website" />
		<meta property="og:url" content="" />
	    <meta property="og:image" content=""/>
	    
	    <meta name="description" content="It is an on-demand delivery service that connects you to the nearest vegetable hawkers .Veg Vendors aim is to amend the traditional way of people buying groceries to make the local shopping experience more convenient and amicable. We are substituting your visits to the nearby vegetable hawkers with a few taps on the mobile/laptop/computer/tab.This is a user-friendly site/app which provides easy surfing and also offers easy modes of payments-Credit/Debit card, Cash on Delivery (COD), E-wallet/paytm.So, if you want fresh veggies on your doorstep, just go to www.vegvendors.in" />

	    <meta name="keywords" content="vegvendors.com,vegvendors.in,sabji,sabzi,sabjiwala ,sabjiwaala,sabziwaalaonline vegetable shopping,veggie, veggies,vegetables online, veg, shop,peddler,vegetable,vegetables,hawker,vendor,vegetable vendor,vegvendor,veg vendor,vender,veg vender,vegvender,online grocery store,purchase,buy vegetables,buy,bye, home delivery,delivery, doorstep,how to order vegetables,sabzi online,online on demand,vendor,vender online,vegvenders.com,vegvenders.in,shopping india,buy groceries online,online grocery in delhi,online grocery in rohini,online " />
		<meta name="author" content="VEGVENDORS" />

		<link rel="canonical" href="http://www.vegvendors.in/" />
		<meta property="og:locale" content="en_US" />
		<meta property="og:type" content="website" />
		<meta property="og:title" content="VEGVENDORS" />
		<meta property="og:description" content="It is an on-demand delivery service that connects you to the nearest vegetable hawkers .Veg Vendors aim is to amend the traditional way of people buying groceries to make the local shopping experience more convenient and amicable. We are substituting your visits to the nearby vegetable hawkers with a few taps on the mobile/laptop/computer/tab.This is a user-friendly site/app which provides easy surfing and also offers easy modes of payments-Credit/Debit card, Cash on Delivery (COD), E-wallet/paytm.So, if you want fresh veggies on your doorstep, just go to www.vegvendors.in"/>
		<meta property="og:site_name" content="VEGVENDORS" />

		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		
		<?php
?>