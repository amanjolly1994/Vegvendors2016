<html>
   
   <head>
      <title>PHP Form Validation</title>
   </head>
   
   <body>
      
   
      <h2>login form</h2>
	  
	  
	 
	  
	  
	  
		 
      
      <form method = "post" action = "final.php">
         <table>
            
            
            
            
            <tr>
               <td>Phone no.:</td>
               <td><input type = "text" name = "phone"></td>
			   
            </tr>
			
			<tr>
               <td>
                  <input type = "submit" name = "submit" value = "Submit"> 
               </td>
            </tr>
			
	
               
         </table>
      </form>
	  
      
      
      
   </body>
</html>