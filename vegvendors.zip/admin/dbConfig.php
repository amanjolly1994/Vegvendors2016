<?php
//db details
include ("../dbConfig.php");
?>
