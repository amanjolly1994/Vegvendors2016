<?php

?>
	<div class="top-logo-holder">
		<a href="http://vegvendors.in/"><img src="/theme/images/logos/full-logo.png" alt="vegvendors"/></a>
	</div>	




<?php

?>