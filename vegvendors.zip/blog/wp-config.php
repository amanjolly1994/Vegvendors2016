<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'admin_blog');

/** MySQL database username */
define('DB_USER', 'admin_blogger');

/** MySQL database password */
define('DB_PASSWORD', '@veg.vendors.in@2016');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'G{X}:m;{F(PO#-I7kB!Bz+Hn0KsX_VY|zKX(<j@o^yy>3@mccVKo55lG,zO-9Rdl');
define('SECURE_AUTH_KEY',  'TZ`ny0AgN1Jj|%w0b?i?>uWcWO6xtv0.CUa!_SG-^0dmV0G@&1h?JVTO9niS7:{S');
define('LOGGED_IN_KEY',    'nIN<4-l@Hs-@N3.GzLEsYL9.5 :y|tCmqvJQDcn;<z$)K(m*Jm0ss3VrFLP8a`S}');
define('NONCE_KEY',        'B%41&p-Pgi{1>S[[0+AU:=Ze-[NtTc^@ksV_L3X*N<Nu`qG{$6qrZrjHJbCW`T:-');
define('AUTH_SALT',        '.fk=NUGU/T:6}C#gT(3bl{y(oM=i,VADJ?tjh7QB}VZPxA.kXnqG.OMQ0MlUjrY?');
define('SECURE_AUTH_SALT', '%HD8i5XlQXh[M:+H( FFP6BN#06>gh UG1yoR:w|Zru3!E(D(^rt<ew+0Zeo=OSX');
define('LOGGED_IN_SALT',   '^nV%xfhk+n$ D{[)-v~p6%%$o?3I]>/=0!!r>&~LJ>*4l[9x_0x=B-_`ZJ95`zKh');
define('NONCE_SALT',       '~MmC8u_)H1JXXUe/hG^H e^;G~5Ts)1c:GK}b(p3=Lz=43Db@+{1SK9OMaC`QXoq');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
