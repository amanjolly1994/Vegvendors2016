<?php

	session_start();
	
	echo $_COOKIE['subareacode'];
	echo "asasd".$_SESSION['cat1vendor'];

?>