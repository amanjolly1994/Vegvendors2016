<!DOCTYPE html>
<html>
<body>

<form action="crashReporter.php" method="post" enctype="multipart/form-data">
  <!-- flag:<br>
  <input type="text" name="flag" >
  <br><br> -->

text:<br>
  <input type="test" name="data" >
  <br>
  uid:<br>
  <input type="text" name="uid" >
  <br><br>
  <input type="submit" value="Submit">
</form> 

<p>If you click the "Submit" button, the form-data will be sent to a page called "action_page.php".</p>

</body>
</html>
