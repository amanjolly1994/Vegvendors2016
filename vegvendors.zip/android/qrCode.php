<?php

	if( $_POST["code"] )
	{
		echo "Bhuwan";
	}

?>