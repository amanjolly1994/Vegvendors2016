<!DOCTYPE html>
<html>
<body>

<form action="login.php" method="post">
  flag:<br>
  <input type="text" name="flag" value="Mouse">
  <br><br>

  email:<br>
  <input type="text" name="id" value="Mickey">
  <br>
  pwd:<br>
  <input type="text" name="password" value="Mouse">
  <br><br>
  <input type="submit" value="Submit">
</form> 

<p>If you click the "Submit" button, the form-data will be sent to a page called "action_page.php".</p>

</body>
</html>
