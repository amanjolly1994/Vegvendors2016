<?php 


echo date('Y-m-d_H-i-s'); 

{
	 echo $y=date('Y-m-d_H-i-s'); 


}
?>