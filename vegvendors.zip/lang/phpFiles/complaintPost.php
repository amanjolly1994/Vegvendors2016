<?php

// session_start();
// require_once 'dbConfig.php';
// require '../../PHPMailerAutoload.php';
//
// if($_POST)
// {
//   $uid = $_SESSION['uid'];
//   $order_id = $_POST['order-list'];
//   $complaint = $_POST['complaint-text'];
//   $s = substr(str_shuffle(str_repeat("ABCDEFGHIJKLMNOPQRSTUWXYZ", 2)), 0, 2);
//
// }

echo $s = substr(str_shuffle(str_repeat("ABCDEFGHIJKLMNOPQRSTUWXYZ", 2)), 0, 2);
?>
