<?php
include ("set_vegnmlist.php"); 
include ("set_mainAreaJson.php");
include ("set_mainJson.php");
?>